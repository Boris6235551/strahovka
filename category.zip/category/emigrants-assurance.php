<?php
/*
Template Name: emigrants-assurance
*/

get_header();
?>
        <div class='wrapper'>
            <div class='sidebar'>
                <div class='sidebar_block'>
                    <h2>Физическим лицам:</h2>
                    <h3>Авто</h3>
                    <ul class='sidebar_nav blue'>
                        <li>
                            <a href='/fiz/auto/kasko'>КАСКО</a>
                        </li>
                        <li>
                            <a href='/fiz/auto/osgo'>ОСГО</a>
                        </li>
                        <li>
                            <a href='/fiz/auto/green-card'>Зеленая карта</a>
                        </li>
                        <li>
                            <a href='/fiz/auto/accidents'>Несчастные случаи</a>
                        </li>
                    </ul>
                </div>
                <div class='sidebar_block'>
                    <h3>Жилье</h3>
                    <ul class='sidebar_nav orange'>
                        <li>
                            <a href='/fiz/house/house'>Строение</a>
                        </li>
                        <li>
                            <a href='/fiz/house/flats'>Квартиры</a>
                        </li>
                        <li>
                            <a href='/fiz/house/owners-responsibility'>Ответственность владельцев квартир</a>
                        </li>
                    </ul>
                </div>
                <div class='sidebar_block'>
                    <h3>Здоровье</h3>
                    <ul class='sidebar_nav red'>
                        <li>
                            <a href='/fiz/health/accidents'>Несчастные случаи</a>
                        </li>
                        <li>
                            <a href='/fiz/health/dms'>Добровольное медицинское</a>
                        </li>
                        <li>
                            <a class='active' href='/fiz/health/emigrants-assurance'>Для выезжающих</a>
                        </li>
                    </ul>
                </div>
                <div class='sidebar_block'>
                    <h2>Смотрите также:</h2>
                    <ul class='related'>
                        <li>
                            <a href='/corp'>Услуги для корпоративных клиентов</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class='content'>
                <div class='breadcrumbs'>
                    <a href="/">Главная</a>
                    <a href="/fiz/health">Здоровье</a>
                    Для выезжающих
                </div>
                <h2>Для выезжающих</h2>
                <div class='category-health post'>
                    <div class='post_text'>
                        <p>Выезжая за границу, надо быть готовым к тому, что всякое может случиться. Как показывает практика, предусмотрительные граждане всегда делают выбор в пользу страхования от несчастных случаев и болезней на время командировки или отдыха за пределами Республика Беларусь.</p>
                        <p>Наши предложения <strong>включают:</strong></p>
                        <ul>
                            <li>Амбулаторное или стационарное медицинское лечение;</li>
                            <li>Экстренную стоматологическую помощь;</li>
                            <li>Расходы на медицинскую транспортировку;</li>
                            <li>Оплату телефонных разговоров;</li>
                            <li>Эвакуацию детей;</li>
                            <li>Досрочное возвращение;</li>
                            <li>Оплату переговоров со службой по страховому случаю.</li>
                        </ul>
                    </div>
                    <div class='reasons'>
                        <h3>В итоге, почему же Вам выгоднее обратиться именно к нам?</h3>
                        <h4>Все просто, кроме всего вышеперечисленного мы также:</h4>
                        <div class='row'>
                            <div class='reason_block'>
                                <p>Напоминаем об очередных взносах и заканчивающихся договорах</p>
                            </div>
                            <div class='reason_block'>
                                <p>Работаем с понедельника по субботу без обеда</p>
                            </div>
                            <div class='reason_block last'>
                                <p>Опыт работы в сфере страхования более 10 лет</p>
                            </div>
                        </div>
                        <div class='row'>
                            <div class='reason_block'>
                                <p>Бесплатная консультация по любому вопросу страхования, даже если застрахованы вы не через нашу компанию</p>
                            </div>
                            <div class='reason_block'>
                                <p>Ответственный и дружелюбный персонал</p>
                            </div>
                            <div class='reason_block last'>
                                <p>Удобное расположение офиса со своей стоянкой, где вы всегда найдете место припарковать свой автомобиль</p>
                            </div>
                        </div>
                        <div class='order_service'>
                            <a href='/fiz/health/emigrants-assurance/request/new'>
                                <img alt='Заказать' src='<?php echo get_template_directory_uri(); ?>/img/order_green_button.png'>
                                страхование &laquo;Для выезжающих&raquo;
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php
get_footer();